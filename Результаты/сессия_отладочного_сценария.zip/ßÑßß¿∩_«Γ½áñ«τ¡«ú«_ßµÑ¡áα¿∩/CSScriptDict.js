CSStopExecution=false;
CSAct = new Object;